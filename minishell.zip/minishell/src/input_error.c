/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   input_error.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchalak <rchalak@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/10 11:10:35 by rchalak           #+#    #+#             */
/*   Updated: 2024/12/10 11:10:36 by rchalak          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

/**
 * Checks for various types of errors in the input string before execution.
 *
 * This function evaluates the provided input string for potential errors
 * such as:
 * - Empty input
 * - Unclosed quotes
 * - Invalid syntax
 * - Failed heredoc handling
 *
 * If some errors are found, the function sets the exit status,
 * frees the input string, and returns TRUE (indicating an error).
 * Otherwise, it returns FALSE, indicating no errors.
 **/
int	has_input_error(char *input, int *exit_status, t_env *minienv)
{
	int	result;

	result = FALSE;
	if (is_empty(input))
		result = TRUE;
	else if (has_unclosed_quotes(input))
		result = TRUE;
	else if (is_invalid_syntax(input))
	{
		*exit_status = 2;
		result = TRUE;
	}
	else if (handle_heredoc(input, exit_status, minienv) == FAILED)
		result = TRUE;
	if (result == TRUE)
		free(input);
	return (result);
}
