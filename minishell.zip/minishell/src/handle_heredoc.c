/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   handle_heredoc.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchalak <rchalak@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/10 11:10:27 by rchalak           #+#    #+#             */
/*   Updated: 2024/12/17 15:30:18 by rchalak          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

/**
 * Searches for a heredoc operator ("<<") in the given string.
 *
 * This function scans through a string to find the position of the
 * heredoc operator ("<<"). It correctly handles quoted sections within
 * the string (both single and double quotes) by skipping over them.
 * If the operator is found, a pointer to its position in the string is
 * returned; otherwise, NULL is returned.
 **/
char	*get_heredoc_position(char *str)
{
	while (*str && str[1])
	{
		if (*str == '\'')
		{
			str++;
			while (*str != '\'')
				str++;
		}
		if (*str == '"')
		{
			str++;
			while (*str != '"')
				str++;
		}
		if (*str == '<' && str[1] == '<')
			return (str);
		str++;
	}
	return (NULL);
}

/**
 * Generates a unique temporary filename for heredoc storage.
 *
 * This function creates a unique filename for a temporary file to store
 * heredoc input. The filename is based on the provided heredoc number, which
 * is converted to a string and appended to the base "/tmp/heredoc". The
 * resulting filename is dynamically allocated and returned.
 **/
static char	*tmp_filename(int heredoc_number)
{
	char	filename[30];
	char	*number_str;

	ft_bzero(filename, 30);
	number_str = ft_itoa(heredoc_number);
	ft_strlcat(filename, "/tmp/heredoc", 30);
	ft_strlcat(filename, number_str, 30);
	free(number_str);
	return (ft_strdup(filename));
}

/**
 * Reads input until a delimiter is encountered
 * and writes it to a temporary file.
 *
 * This function handles a Here-document (heredoc) by reading user input until

 * the specified delimiter is reached. It expands the exit status and environment
 * variables within the input, then writes the processed input
 * to a temporary file.
 * If the delimiter is not found before EOF, a warning is printed. The function
 * then frees resources, closes the file, and exits.
 **/
void	read_heredoc(int *exit_status, t_env *minienv, char *delimiter,
		int heredoc_number)
{
	char	*line_read;
	char	*filename;
	int		tmp_file_fd;

	filename = tmp_filename(heredoc_number);
	tmp_file_fd = open(filename, O_CREAT | O_RDWR | O_TRUNC, 0644);
	free(filename);
	line_read = readline("> ");
	while (line_read && !str_equal(line_read, delimiter))
	{
		expand_exit_status(&line_read, *exit_status);
		expand_variables(&line_read, minienv);
		ft_putstr_fd(line_read, tmp_file_fd);
		ft_putchar_fd('\n', tmp_file_fd);
		free(line_read);
		line_read = readline("> ");
	}
	if (!line_read)
		print_error_msg("warning: heredoc delimited by EOF. Wanted", delimiter);
	free(line_read);
	close(tmp_file_fd);
	free(delimiter);
	free_minienv(&minienv);
	rl_clear_history();
	exit(EXIT_SUCCESS);
}

/**
 * Executes a heredoc (here document) process.
 *
 * This function handles the execution of a
 * heredoc operation by forking a child process.
 * The child process reads input from the user
 * until the specified delimiter is encountered.
 *
 * - The function first forks a new process to handle the heredoc.
 * - The parent process waits for the child process
 *   to finish and captures its exit status.
 * - If the fork fails, an error message is printed.
 * - If the fork succeeds, the child process reads the heredoc input,
 *   while the parent waits for the child to finish.
 * - After the child process completes,
 *   the parent process restores the main signals and checks the exit status.
 **/
int	exec_heredoc(char *delimiter, int heredoc_number, int *exit_status,
		t_env *minienv)
{
	int	child_pid;

	child_pid = fork();
	define_heredoc_signals(child_pid);
	exit_status = get_exit_status();
	if (child_pid == -1)
		print_perror_msg("fork - heredoc_prompt", delimiter);
	else if (child_pid == 0)
		read_heredoc(exit_status, minienv, delimiter, heredoc_number);
	else
	{
		*exit_status = wait_for_child(child_pid, TRUE);
		define_main_signals();
		if (*exit_status != EXIT_SUCCESS)
			return (FAILED);
	}
	return (SUCCESS);
}

/**
 * Handles heredoc operators (<<) in the input string.
 *
 * This function recursively processes heredoc operators within the input,
 * substituting them with a unique identifier and executing the heredoc logic.
 *
 * - It starts by finding the position of the heredoc operator in the input.
 * - If a heredoc is found,
 *   it assigns a unique number (decrementing `heredoc_number`),
 *   and then replaces the operator with this unique identifier.
 * - It then retrieves the label (delimiter) for the heredoc,
 *   executes the heredoc operation, and handles any potential failure.
 * - If successful, the function continues processing the input
 *   for any further heredoc operators.
 **/
int	handle_heredoc(char *input, int *exit_status, t_env *minienv)
{
	static int	heredoc_number;
	char		*heredoc_position;
	char		*delimiter;

	heredoc_number = -1;
	heredoc_position = get_heredoc_position(input);
	if (!heredoc_position)
		return (SUCCESS);
	heredoc_number--;
	*heredoc_position = heredoc_number;
	heredoc_position++;
	delimiter = get_label_name(heredoc_position);
	if (!exec_heredoc(delimiter, heredoc_number, exit_status, minienv))
	{
		free(delimiter);
		return (FAILED);
	}
	free(delimiter);
	return (handle_heredoc(input, exit_status, minienv));
}
