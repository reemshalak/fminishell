/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchalak <rchalak@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/10 11:11:11 by rchalak           #+#    #+#             */
/*   Updated: 2024/12/23 11:17:29 by rchalak          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

int	minishell(t_env *minienv)
{
	int		exit_status;
	char	*input;
	char	**commands;

	exit_status = EXIT_SUCCESS;
	while (TRUE)
	{
		define_main_signals();
		input = prompt_input(minienv);
		if (has_input_error(input, &exit_status, minienv))
			continue ;
		handle_expansions(&input, minienv, exit_status);
		if (!has_pipe(input))
		{
			execute_one_command(input, &minienv);
		}
		else
		{
			commands = split_commands(input);
			free(input);
			execute_multiple_commands(commands, &minienv);
			free_array(commands);
		}
	}
	return (*get_exit_status());
}

int	main(int argc, char **argv, char **envp)
{
	if (argv && argc > 1)
	{
		ft_putstr_fd("\033[0;31m Minishell does not take arguments :/\n",
			STDOUT_FILENO);
		return (EXIT_FAILURE);
	}
	printf("\033[32m"
		"/* ****************************************************** */\n"
		"/* * ███████████   █████   █████ █████ █████   ████████ * */\n"
		"/* *░░███░░░░░███ ░░███   ░░███ ░░███ ░░███   ███░░░░███* */\n"
		"/* * ░███    ░███  ░███    ░███  ░███  ░███ █░░░    ░███* */\n"
		"/* * ░██████████   ░███████████  ░███████████   ███████ * */\n"
		"/* * ░███░░░░░███  ░███░░░░░███  ░░░░░░░███░█  ███░░░░  * */\n"
		"/* * ░███    ░███  ░███    ░███        ░███░  ███      █* */\n"
		"/* * █████   █████ █████   █████       █████ ░██████████* */\n"
		"/* *░░░░░   ░░░░░ ░░░░░   ░░░░░       ░░░░░  ░░░░░░░░░░ * */\n"
		"/* ****************************************************** */\n"
		"\033[0m");
	return (minishell(init_minienv(envp)));
}
