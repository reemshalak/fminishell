/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strch.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hkhadra <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/10 16:40:55 by hkhadra           #+#    #+#             */
/*   Updated: 2024/06/10 16:40:56 by hkhadra          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strchr(const char *s, int c)
{
	unsigned char	s2;

	s2 = (unsigned char)c;
	while (*s)
	{
		if (*s == s2)
			return ((char *)s);
		s++;
	}
	if (s2 == '\0')
		return ((char *)s);
	return (NULL);
}
