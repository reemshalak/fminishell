/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstmap_bonus.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hkhadra <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/14 15:12:26 by hkhadra           #+#    #+#             */
/*   Updated: 2024/06/14 15:12:38 by hkhadra          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

t_list	*ft_lstmap(t_list *lst, void *(*f)(void *), void (*del)(void *))
{
	t_list	*newlst;
	t_list	*temp;
	t_list	*head;

	if (!lst || !f)
		return (NULL);
	newlst = ft_lstnew((*f)(lst->content));
	if (!newlst)
		return (NULL);
	head = newlst;
	lst = lst->next;
	while (lst)
	{
		temp = ft_lstnew((*f)(lst->content));
		if (!temp)
		{
			ft_lstclear(&head, del);
			return (NULL);
		}
		ft_lstadd_back(&newlst, temp);
		newlst = newlst->next;
		lst = lst->next;
	}
	return (head);
}
