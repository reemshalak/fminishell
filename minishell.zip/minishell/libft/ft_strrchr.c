/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strrchr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hkhadra <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/10 16:41:48 by hkhadra           #+#    #+#             */
/*   Updated: 2024/06/10 16:41:49 by hkhadra          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strrchr(const char *s, int c)
{
	unsigned char	chr;
	size_t			i;
	const char		*found;

	chr = (unsigned char)c;
	i = 0;
	found = NULL;
	while (s[i] != '\0')
	{
		if (s[i] == chr)
			found = &s[i];
		i++;
	}
	if (chr == '\0')
		return ((char *)&s[i]);
	return ((char *)found);
}
