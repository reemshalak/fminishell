/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_calloc.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hkhadra <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/12 12:44:12 by hkhadra           #+#    #+#             */
/*   Updated: 2024/06/12 12:44:14 by hkhadra          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_calloc(size_t num, size_t size)
{
	void	*ptr;

	if (num != 0 && size > ((size_t)-1) / num)
		return (NULL);
	ptr = malloc(num * size);
	if (ptr)
		ft_memset(ptr, 0, num * size);
	return (ptr);
}
