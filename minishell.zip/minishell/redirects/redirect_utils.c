/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   redirect_utils.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchalak <rchalak@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/10 11:04:15 by rchalak           #+#    #+#             */
/*   Updated: 2024/12/10 11:04:18 by rchalak          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

/*
 * This function searches for the first occurrence of a specified redirection
 * character (`redirect_char`) in the input string `str`, while ignoring
 * characters within single and double quotes.
 *
 * Steps:
 * 1. Iterate through the input string.
 * 2. Skip over text within single quotes (`'`).
 * 3. Skip over text within double quotes (`"`).
 * 4. Return the pointer to the first occurrence of `redirect_char` found
 *    outside of quoted sections.
 * 5. If `redirect_char` is not found, return `NULL`.
 *
 * Parameters:
 * - `str`: The input string to search.
 * - `redirect_char`: The redirection character to find.
 *
 * Returns:
 * - Pointer to the position of `redirect_char` in the string.
 * - `NULL` if `redirect_char` is not found.
 */
char	*get_redirect_position(char *str, char redirect_char)
{
	while (*str)
	{
		if (*str == '\'')
		{
			str++;
			while (*str != '\'')
				str++;
		}
		if (*str == '"')
		{
			str++;
			while (*str != '"')
				str++;
		}
		if (*str == redirect_char)
			return (str);
		str++;
	}
	return (NULL);
}

/*
 * This function scans through a given string to locate
 * the next redirection operator or any invalid token.
 * It skips over quoted strings (both single and double quotes)
 * and returns the first encountered redirection operator.
 *
 * Redirection operators include:
 * - `<` for input redirection
 * - `>` for output redirection
 * - `<` or `>` followed by another `<` or `>`
 *		for here-documents or append redirections
 *
 * * Returns:
 * - The first occurrence of a redirection operator
 *   (`<`, `>`) or an invalid token.
 * - `0` if no such operator or token is found.
 */
//Example: Hass'an'11"s",<
char	get_next_redirect(char *str)
{
	while (*str)
	{
		if (*str == '\'')
		{
			str++;
			while (*str != '\'')
				str++;
		}
		if (*str == '"')
		{
			str++;
			while (*str != '"')
				str++;
		}
		if (*str == '<' || *str == '>' || *str < 0)
			return (*str);
		str++;
	}
	return (0);
}

void	redirect_fd(int fd_to_redirect, int fd_location)
{
	dup2(fd_to_redirect, fd_location);
	close(fd_to_redirect);
}

void	redirect_fds(int fd_in, int fd_out)
{
	if (fd_in != STDIN_FILENO)
		redirect_fd(fd_in, STDIN_FILENO);
	if (fd_out != STDOUT_FILENO)
		redirect_fd(fd_out, STDOUT_FILENO);
}
