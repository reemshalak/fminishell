/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   syntax.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchalak <rchalak@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/10 11:11:36 by rchalak           #+#    #+#             */
/*   Updated: 2024/12/10 11:11:37 by rchalak          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

int	starts_with_pipe(char *input)
{
	if (input[0] == '|')
		return (syntax_error("|"));
	return (FALSE);
}

/*
 * This function processes the input string to handle redirection operators
 * without considering labels (e.g., file names or commands following the
 * redirection operators). It identifies and processes the next redirection
 * operator (either `<<` for here-documents or `>>` for appending redirection),
 * and checks if there is valid content following the operator.
 *
 * Steps:
 * 1. Determine the type of the next redirection operator to process.
 * 2. Locate the position of this redirection operator in the input string.
 * 3. Skip over the redirection operator and any following whitespace.
 * 4. Check if the remainder of the input is empty or contains invalid tokens.
 * 5. If there are syntax errors or unexpected tokens, handle them accordingly.
 * 6. Recursively process the remaining input after the redirection operator.
 *
 * Returns:
 * - TRUE if the input is valid and redirection is processed successfully.
 * - FALSE if there is a syntax error or unexpected token encountered.
 */
int	redirect_without_label(char *input)
{
	char	*redirect_position;
	char	next_redirect;

	next_redirect = get_next_redirect(input);
	redirect_position = get_redirect_position(input, next_redirect);
	if (!redirect_position)
		return (FALSE);
	if (redirect_position[0] == '<' && redirect_position[1] == '<')
		redirect_position++;
	else if (redirect_position[0] == '>' && redirect_position[1] == '>')
		redirect_position++;
	redirect_position++;
	while (*redirect_position == ' ' || *redirect_position == '\t')
		redirect_position++;
	if (*redirect_position == '\0')
		return (syntax_error("newline"));
	if (is_invalid_token(*redirect_position))
		return (unexpected_token(redirect_position));
	return (redirect_without_label(redirect_position));
}

int	has_empty_pipe(char *input)
{
	char	*next_pipe;

	next_pipe = get_next_pipe(input);
	if (!next_pipe)
		return (FALSE);
	next_pipe++;
	while (*next_pipe == ' ' || *next_pipe == '\t')
		next_pipe++;
	if (*next_pipe == '|')
		return (syntax_error("|"));
	return (has_empty_pipe(next_pipe));
}

int	is_invalid_syntax(char *input)
{
	if (starts_with_pipe(input))
		return (TRUE);
	if (redirect_without_label(input))
		return (TRUE);
	if (has_empty_pipe(input))
		return (TRUE);
	return (FALSE);
}
