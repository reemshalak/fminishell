/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   handle_expansions.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchalak <rchalak@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/10 11:08:01 by rchalak           #+#    #+#             */
/*   Updated: 2024/12/17 10:29:06 by rchalak          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

void	handle_expansions(char **input, t_env *minienv, int exit_status)
{
	exit_status = *get_exit_status();
	expand_exit_status(input, exit_status);
	expand_variables(input, minienv);
}
