/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   exit.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchalak <rchalak@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/10 11:08:22 by rchalak           #+#    #+#             */
/*   Updated: 2024/12/23 14:56:45 by rchalak          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

/*
 * Checks if a string can be represented as a valid long long integer.
 *
 * The function first checks if the string length exceeds the maximum
 * digits that a long long can represent. If it matches the smallest
 * possible long long, the function returns true. Otherwise, it converts
 * the string to a long long while checking for non-numeric characters
 * and overflow conditions.
 */
int	converts_to_longlong(char *str)
{
	long long	out;
	int			c;

	if (ft_strlen(str) > 20)
		return (0);
	if (ft_strncmp(str, "-9223372036854775808", 21) == 0)
		return (1);
	out = 0;
	if (*str == '-' || *str == '+')
		str++;
	while (*str)
	{
		if (*str < '0' || *str > '9')
			return (0);
		c = *str - '0';
		if (out > (LLONG_MAX - c) / 10)
			return (0);
		out = out * 10 + c;
		str++;
	}
	return (1);
}
/*
 * Validates the arguments for the "exit" command.
 * 
 * - If no arguments are provided, the function returns 0, allowing the
 *   shell to exit normally.
 * - If the first argument is not a valid number, it frees resources
 *   and exits with an error message.
 * - If there are more than two arguments, it sets the exit status to
 *   indicate failure and returns EXIT_FAILURE, without exiting or freeing.
 */

static int	check_args_error(char **args)
{
	char	*exit_status;

	if (!args || !args[1])
		return (0);
	exit_status = args[1];
	if (!converts_to_longlong(exit_status))
	{
		free_array(args);
		exit_with_error("exit", "numeric argument required", BUILTIN_MISUSE);
	}
	if (args[2] != NULL)
	{
		ft_putstr_fd("exit: too many arguments\n", STDERR_FILENO);
		set_exit_status(EXIT_FAILURE);
		return (EXIT_FAILURE);
	}
	return (0);
}
/*
 * Implements the "exit" built-in command, handling cleanup and termination.
 * 
 * - If there are too many arguments, the function sets the exit status
 *   and returns without performing any cleanup or exiting.
 * - If arguments are valid, it frees resources such as the environment,
 *   history, and file descriptors, then exits with the provided status.
 * - If no arguments are provided, the shell exits successfully.
 */

int	builtin_exit(char **args, t_env **minienv)
{
	int	check_result;
	int	exit_status;

	check_result = check_args_error(args);
	if (check_result == EXIT_FAILURE)
		return (*get_exit_status());
	ft_putstr_fd("exit\n", STDOUT_FILENO);
	rl_clear_history();
	free_minienv(minienv);
	close_all_fds();
	if (args && args[1])
	{
		exit_status = ft_atoll(args[1]);
		free_array(args);
		exit(exit_status);
	}
	free_array(args);
	exit(*get_exit_status());
	return (0);
}

// Setter function to update the exit status
void	set_exit_status(int status)
{
	int	*code;

	code = get_exit_status();
	*code = status;
}

// Getter function to retrieve the exit status
int	*get_exit_status(void)
{
	static int	status;

	return (&status);
}
