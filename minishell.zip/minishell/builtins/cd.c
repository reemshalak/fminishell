/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   cd.c                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchalak <rchalak@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/10 11:03:03 by rchalak           #+#    #+#             */
/*   Updated: 2024/12/10 11:03:12 by rchalak          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

int	cd_error(void)
{
	print_error_msg("cd", "too many arguments");
	return (EXIT_FAILURE);
}

/**
 * get_cd_path - Determines the path for the cd command.
 *
 * The function checks the provided arguments and returns the correct path
 * to change into. It handles special cases like `cd
	-` to change to the previous
 * directory and `cd ~` to change to the home directory.
 * If no special cases apply, it returns the argument provided as the path.
 * If the path is invalid (e.g., `OLDPWD` is not set), it returns NULL.
 *
 * Returns: The path to change into, or NULL if an error occurs.
 **/

char	*get_cd_path(char **args, t_env *minienv)
{
	char	*path;
	char	*oldpwd;

	if (args[1] == NULL || *args[1] == '\0')
		path = minienv_value("HOME", minienv);
	else if (str_equal(args[1], "-"))
	{
		oldpwd = minienv_value("OLDPWD", minienv);
		if (!oldpwd || !*oldpwd)
		{
			print_perror_msg("cd", "-");
			return (NULL);
		}
		path = oldpwd;
	}
	else if (str_equal(args[1], "~"))
		path = minienv_value("HOME", minienv);
	else
		path = args[1];
	return (path);
}

/**
 * update_pwd - Updates the PWD and OLDPWD environment variables.
 *
 * After successfully changing the directory, this function updates the `PWD`
 * environment variable to the current directory and updates `OLDPWD` with the
 * previous directory. It uses `getcwd` to obtain the current working directory.
 *
 * This function assumes the directory change was successful and performs the
 * necessary updates to maintain the environment state.
 **/
void	update_pwd(t_env *minienv)
{
	char	*pwd;
	char	cwd[PATH_MAX];

	pwd = minienv_value("PWD", minienv);
	if (pwd && *pwd)
		minienv_update("OLDPWD", pwd, minienv);
	if (getcwd(cwd, PATH_MAX))
		minienv_update("PWD", cwd, minienv);
}

/**
 * cd - Changes the current directory to the specified path.
 *
 * The function changes the current working directory based on the argument
 * provided. It handles different cases such as changing to the home directory,
 * previous directory (using `OLDPWD`), or a specified path. If the directory
 * change is successful,
	it updates the `PWD` and `OLDPWD` environment variables.
 * Returns EXIT_SUCCESS on success, or EXIT_FAILURE if an error occurs.
 **/
int	cd(char **args, t_env *minienv)
{
	char	*path;

	if (args[1] && args[2])
		return (cd_error());
	path = get_cd_path(args, minienv);
	if (!path || chdir(path) != 0)
	{
		print_perror_msg("cd", path);
		return (EXIT_FAILURE);
	}
	update_pwd(minienv);
	return (EXIT_SUCCESS);
}
