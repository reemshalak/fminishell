/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   signals.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchalak <rchalak@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/10 11:03:39 by rchalak           #+#    #+#             */
/*   Updated: 2024/12/17 16:03:04 by rchalak          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

/*
Ignores the signal number since it's not used.
Prints a newline to move the cursor to a new line.
Notifies the readline library that a new line is starting.
Clears the current input line by replacing it with an empty string.
Redisplays the prompt on a fresh line, making the shell look clean after Ctrl+C.
*/
static void	custom_handle(int sig)
{
	(void)sig;
	set_exit_status(128 + SIGINT);
	ft_putstr_fd("\n", STDOUT_FILENO);
	rl_replace_line("", 0);
	rl_on_new_line();
	rl_redisplay();
}

/*
This function sets up signal handling for SIGINT and SIGQUIT.
- SIGINT (Ctrl+C) will be handled by a custom handler.
- SIGQUIT (Ctrl+\) will be ignored.
*/
void	define_main_signals(void)
{
	struct sigaction	sa_sigint;
	struct sigaction	sa_sigquit;

	sa_sigint.sa_handler = &custom_handle;
	sa_sigint.sa_flags = 0;
	sigemptyset(&sa_sigint.sa_mask);
	sigaction(SIGINT, &sa_sigint, NULL);
	sa_sigquit.sa_handler = SIG_IGN;
	sa_sigquit.sa_flags = 0;
	sigemptyset(&sa_sigquit.sa_mask);
	sigaction(SIGQUIT, &sa_sigquit, NULL);
}

/*
** define_execute_signals - Configures signal handling based on process type.
**
** - Initializes signal action structure.
** - Sets default signal handling for the child process.
** - Ignores signals in the parent process.
** - Applies the configuration to SIGINT and SIGQUIT.
*/
void	define_execute_signals(int child_pid)
{
	struct sigaction	sa;

	sa.sa_flags = 0;
	sigemptyset(&sa.sa_mask);
	if (child_pid == 0)
		sa.sa_handler = SIG_DFL;
	else
		sa.sa_handler = SIG_IGN;
	sigaction(SIGINT, &sa, NULL);
	sigaction(SIGQUIT, &sa, NULL);
}

/*
** define_heredoc_signals - Configures signal handling for heredoc processing.
**
** - Initializes signal actions for SIGINT and SIGQUIT.
** - Sets default handling for SIGINT in the child process;
	ignores it in the parent.
** - Always ignores SIGQUIT.
** - Applies these configurations to SIGINT and SIGQUIT.
*/
void	define_heredoc_signals(int child_pid)
{
	struct sigaction	sa_sigint;
	struct sigaction	sa_sigquit;

	sa_sigint.sa_flags = 0;
	sigemptyset(&sa_sigint.sa_mask);
	if (child_pid == 0)
		sa_sigint.sa_handler = SIG_DFL;
	else
		sa_sigint.sa_handler = SIG_IGN;
	sigaction(SIGINT, &sa_sigint, NULL);
	sa_sigquit.sa_flags = 0;
	sigemptyset(&sa_sigquit.sa_mask);
	sa_sigquit.sa_handler = SIG_IGN;
	sigaction(SIGQUIT, &sa_sigquit, NULL);
}
