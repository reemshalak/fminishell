/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   quote_checker.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchalak <rchalak@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/10 11:12:11 by rchalak           #+#    #+#             */
/*   Updated: 2024/12/12 16:22:22 by rchalak          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

static int	print_error(void)
{
	ft_putstr_fd("Error: Unclosed quotes detected\n", STDERR_FILENO);
	set_exit_status(2);
	return (1);
}

/**
 * Checks if a string contains unclosed quotes.
 *

	* This function scans the string for single (') or double (") quotes and ensures
 * that each opening quote has a corresponding closing quote.
 * If any quote is left unclosed, the function returns 1.
 * The function recurses through the string to ensure that nested
 * or multiple pairs of quotes are handled correctly.
 *
 * Examples:
 * 1. Input: "Hello 'world"  -> Result: 1 (unclosed single quote)
 * 2. Input: "'Hello' \"world\""  -> Result: 0 (all quotes are closed)
 * 3. Input: "He said, 'It's fine'"  -> Result: 0 (all quotes are closed)
 * 4. Input: "\"Unmatched single quote -> Result: 1 (unclosed double quote)
 * 5. Input: "'Another example\""  -> Result: 1 (unclosed double quote)
 **/
int	has_unclosed_quotes(char *str)
{
	char	last_opened;

	last_opened = 0;
	while (*str && !last_opened)
	{
		if (*str == '\'' || *str == '"')
			last_opened = *str;
		str++;
	}
	while (*str && last_opened)
	{
		if (*str && *str == last_opened)
			last_opened = 0;
		str++;
	}
	if (*str)
		return (has_unclosed_quotes(str));
	else if (!last_opened)
		return (0);
	else
		return (print_error());
}
