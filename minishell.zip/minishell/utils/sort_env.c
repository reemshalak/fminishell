/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sort_env.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchalak <rchalak@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/10 11:12:20 by rchalak           #+#    #+#             */
/*   Updated: 2024/12/10 11:12:44 by rchalak          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

static void	swap_nodes(t_env *a, t_env *b)
{
	char	*temp;

	temp = a->key_pair;
	a->key_pair = b->key_pair;
	b->key_pair = temp;
}

void	sort_env(t_env *minienv)
{
	int		swapped;
	t_env	*current;

	if (!minienv)
		return ;
	swapped = 1;
	while (swapped)
	{
		swapped = 0;
		current = minienv;
		while (current->next)
		{
			if (ft_strncmp(current->key_pair, current->next->key_pair,
					ft_strlen(current->key_pair)) > 0)
			{
				swap_nodes(current, current->next);
				swapped = 1;
			}
			current = current->next;
		}
	}
}
