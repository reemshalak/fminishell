/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   file_descriptors.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchalak <rchalak@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/10 11:11:56 by rchalak           #+#    #+#             */
/*   Updated: 2024/12/10 11:11:57 by rchalak          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

/*
Closes all file descriptors greater than STDERR_FILENO.
Opens a temporary file to determine the highest file descriptor,
then closes all file descriptors from that point down to STDERR_FILENO.
*/
void	close_extra_fds(void)
{
	int	last_open_fd;

	last_open_fd = open("/tmp/highest_fd", O_RDWR | O_CREAT, 0666);
	if (last_open_fd == -1)
		print_perror_msg("open", "/tmp/highest_fd");
	close(last_open_fd);
	while (last_open_fd > STDERR_FILENO)
	{
		last_open_fd--;
		close(last_open_fd);
	}
	if (unlink("/tmp/highest_fd") == -1)
		print_perror_msg("unlink", "/tmp/highest_fd");
}

/*
Closes all standard file descriptors (STDIN, STDOUT, STDERR)
and any additional file descriptors greater than STDERR_FILENO.
Calls	close_extra_fds(void) to handle additional file descriptors.
*/
void	close_all_fds(void)
{
	close_extra_fds();
	close(STDIN_FILENO);
	close(STDOUT_FILENO);
	close(STDERR_FILENO);
}
