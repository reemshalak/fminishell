/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minishell.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchalak <rchalak@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/10 10:58:17 by rchalak           #+#    #+#             */
/*   Updated: 2024/12/23 11:40:27 by rchalak          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MINISHELL_H
# define MINISHELL_H

// Prompt colors
# define GRN "\001\e[1;32m\002"
# define BLU "\033[1;34m\002"
# define CRESET "\001\e[0m\002"
# define PURP "\033[1;35m"
# define WHITE "\033[1;37m"

# define TRUE 1
# define FALSE 0
# define SUCCESS 1
# define FAILED 0
# define PATH_MAX 4096
# define LLONG_MAX 9223372036854775807
# define WHITESPACE " \t\n\v\f\r"

# define NO_REDIRECT -1
# define _GNU_SOURCE
// Allowed Libraries
# include "libft/libft.h"       // libft
# include <fcntl.h>             // open flags
# include <readline/history.h>  // history
# include <readline/readline.h> // readline
# include <signal.h>            // sigaction
# include <stdio.h>             // perror
# include <stdlib.h>            // getenv
# include <sys/stat.h>          // stat
# include <sys/wait.h>          // waitpid
# include <unistd.h>            // getpwd

//////////////////////////////////////////////////////// Error handling section
# define INTERRUPT 128
# define CMD_NOT_FOUND 127
# define PERMISSION_DENIED 126
# define NOT_EXECUTABLE 126
# define OUT_OF_RANGE 255
# define BUILTIN_MISUSE 2
# define FORK_ERROR -1
# define CMD_NOT_FOUND_MSG "command not found"
# define NOT_EXECUTABLE_MSG "Is a directory"

// Static variable to hold the exit status code
//static int g_exit_status = 0;
void				print_error_msg(char *command, char *msg);
void				exit_with_error(char *command, char *msg, int error);
void				print_perror_msg(char *command, char *perror_msg);
void				exit_with_perror(char *command, char *perror_msg,
						int error);
void				print_varname_error_msg(char *command, char *varname);
/////////////////////////////////////////////////////////////// Ends Here

////////////////////////////////////////////////// Mini environment section
typedef struct s_env
{
	char			*key_pair;
	struct s_env	*next;
}					t_env;

t_env				*init_minienv(char **envp);
t_env				*minienv_node(char *name, t_env *minienv);
char				*minienv_value(char *name, t_env *minienv);
void				minienv_update(char *name, char *value, t_env *minienv);
void				list_append(char *key_pair, t_env **list);
char				**minienv_to_envp(t_env *minienv);
void				free_minienv(t_env **minienv);
char				*create_keypair(char *name, char *value);
char				*name_only(char *key_pair);
char				*value_only(char *key_pair);
/////////////////////////////////////////////////////////////// Ends Here

// Built-in section
int					is_builtin(char *command);
int					cd(char **args, t_env *minienv);
int					echo(char **args);
int					pwd(void);
int					builtin_export(char **args, t_env **minienv);
int					env(t_env *envp);
int					unset(char **args, t_env **minienv);
int					builtin_exit(char **args, t_env **minienv);

// utils
int					is_varname(char c);
int					is_valid_varname(char *name);
// Ends Here

/////////////////////////////////////////////////////////////// Executes section
# define IN 0
# define OUT 1

// executes
int					execute_one_command(char *command, t_env **minienv);
int					execute_multiple_commands(char **commands, t_env **minienv);

// one command utils
void				save_original_fd_in(int original_fds[2]);
void				save_original_fd_out(int original_fds[2]);
int					handle_input_redirect(char *command, int original_fds[2]);
int					handle_output_redirect(char *command, int original_fds[2]);

// multiple commands utils
int					*init_children_pid(char **commands);
void				clean_after_execute(int *children_pid);
void				quit_child(char **commands, t_env **minienv);

// execute builtin
int					execute_forked_builtin(char **args, t_env **minienv);
int					execute_builtin(char **args, t_env **minienv);

// execute external
int					execute_external(char **args, t_env *minienv);
char				*get_path(char *command, t_env *minienv);

// wait after fork
int					wait_for_child(int child_pid, int is_last_child);
int					wait_for_children(int children_pid[1024]);

// redirects
void				redirect_fd(int fd_to_redirect, int fd_location);
void				redirect_fds(int fd_in, int fd_out);
int					redirect_input(char *command);
int					redirect_output(char *command);
char				*get_redirect_position(char *str, char redirect_char);
char				get_next_redirect(char *str);
void				close_all_fds(void);
void				close_extra_fds(void);
char				*get_label_name(char *redirect_str);
void				redirect_heredoc(char *command, int heredoc_number);

// pipes
void				handle_pipe(int original_out, char *current_command,
						char **commands);
/////////////////////////////////////////////////////////////// Ends Here

// minishell
int					minishell(t_env *minienv);

// prompt
char				*prompt_input(t_env *minienv);

// syntax
int					has_input_error(char *input, int *exit_status,
						t_env *minienv);
int					has_unclosed_quotes(char *str);
int					is_invalid_syntax(char *input);
int					is_invalid_token(char c);
int					unexpected_token(char *input);
int					syntax_error(char *token);
char				*get_next_pipe(char *str);

// heredoc_prompt
int					handle_heredoc(char *input, int *exit_status,
						t_env *minienv);

// tratativas
void				handle_expansions(char **input, t_env *minienv,
						int exit_status);
void				expand_variables(char **input, t_env *minienv);
void				expand_exit_status(char **input, int exit_status);

// command table
char				**split_commands(char *input);

// tokenizer
char				**split_args(char *command);

// signals
void				define_main_signals(void);
void				define_execute_signals(int child_pid);
void				define_heredoc_signals(int child_pid);

// utils
int					str_equal(const char *str1, const char *str2);
int					is_quote(char c);
int					is_empty(char *str);
int					is_name_delimeter(char c);
int					has_pipe(char *str);
void				free_array(char **arr);
int					arr_len(char **arr);
long long			ft_atoll(const char *str);
void				move_one_forward(char *str);
int					skip_quotes(char *str);
void				sort_env(t_env *minienv);

void				set_exit_status(int status);
int					*get_exit_status(void);

#endif
