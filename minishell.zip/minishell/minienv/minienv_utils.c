/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minienv_utils.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchalak <rchalak@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/10 11:10:02 by rchalak           #+#    #+#             */
/*   Updated: 2024/12/10 11:10:03 by rchalak          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

/*
Searches for a node with a specific name in the minienv list.
Returns the value (char *) inside the node if found, otherwise returns NULL.
*/
char	*minienv_value(char *name, t_env *minienv)
{
	t_env	*aux;

	aux = minienv_node(name, minienv);
	if (!aux)
		return (NULL);
	return (value_only(aux->key_pair));
}

/*
Searches for a node with a specific name in the minienv list.
Returns the node if found, otherwise returns NULL.
*/
t_env	*minienv_node(char *name, t_env *minienv)
{
	t_env	*aux;
	int		size;

	aux = minienv;
	size = ft_strlen(name);
	while (aux)
	{
		if (ft_strncmp(name, aux->key_pair, size) == 0)
		{
			if (aux->key_pair[size] == '=' || aux->key_pair[size] == '\0')
				return (aux);
		}
		aux = aux->next;
	}
	return (NULL);
}

/**
 * minienv_update - Updates or adds an environment variable in the linked list.
 *
 * The function searches for the specified environment variable (`name`) in the
 * linked list (`minienv`). If the variable is found,
	its value is updated to the
 * new `value`. If the variable does not exist, a new key-value pair is created
 * and appended to the list. The function handles memory allocation for the new
 * key-value pair and ensures proper memory management by freeing the old value
 * before assigning the new one.
 **/
void	minienv_update(char *name, char *value, t_env *minienv)
{
	t_env	*aux;
	char	*new_keypair;
	int		i;

	aux = minienv_node(name, minienv);
	if (!aux)
	{
		new_keypair = create_keypair(name, value);
		list_append(new_keypair, &minienv);
		free(new_keypair);
		return ;
	}
	if (value == NULL)
		return ;
	free(aux->key_pair);
	new_keypair = malloc((ft_strlen(name) + ft_strlen(value) + 2)
			* sizeof(char));
	i = 0;
	while (*name)
		new_keypair[i++] = *name++;
	new_keypair[i++] = '=';
	while (*value)
		new_keypair[i++] = *value++;
	new_keypair[i] = '\0';
	aux->key_pair = new_keypair;
}

// void minienv_update(char *name, char *value, t_env *minienv)
// {
//     t_env *aux;
//     size_t name_len;
//     char *new_keypair;

// 	aux = minienv_node(name, minienv);
// 	name_len = ft_strlen(name);
//     if (!aux)
//     {
//         new_keypair = create_keypair(name, value);
//         list_append(new_keypair, &minienv);
//         free(new_keypair);
//         return;
//     }
//     if (value == NULL)
//         return;
//     free(aux->key_pair);
//     if (*value == '\0')
//     {
//         new_keypair = malloc(name_len + 2);
//         if (!new_keypair) 
// 			return;
//         ft_strlcpy(new_keypair, name, name_len + 1);
//         new_keypair[name_len] = '=';
//         new_keypair[name_len + 1] = '\0';
//     }
//     else
//     {
//         new_keypair = malloc(name_len + ft_strlen(value) + 2);
//         if (!new_keypair)
// 			return; 
//         ft_strlcpy(new_keypair, name, name_len + 1);
//         new_keypair[name_len] = '=';
//         ft_strlcpy(new_keypair + name_len + 1, value, ft_strlen(value) + 1);
//     }
//     aux->key_pair = new_keypair;
// }
size_t	minienv_size(t_env *minienv)
{
	size_t	size;
	t_env	*aux;

	size = 0;
	aux = minienv;
	while (aux)
	{
		size++;
		aux = aux->next;
	}
	return (size);
}

/**
 * minienv_to_envp
	- Converts a linked list of environment variables to an array.
 * Returns a dynamically allocated array of strings (`envp`), where each string
 * is a key-value pair from the linked list (`minienv`). The function allocates
 * memory for the array based on the size of the linked list, duplicates each
 * key-value pair, and adds them to the array. The last element of the array
 * is set to `NULL` to indicate the end of the array.
 *
 * Note: The caller is responsible for freeing the memory allocated for the
 * returned array and its elements.
 **/
char	**minienv_to_envp(t_env *minienv)
{
	char	**envp;
	t_env	*aux;
	int		i;

	envp = malloc(sizeof(char *) * (minienv_size(minienv) + 1));
	aux = minienv;
	i = 0;
	while (aux)
	{
		envp[i] = ft_strdup(aux->key_pair);
		i++;
		aux = aux->next;
	}
	envp[i] = NULL;
	return (envp);
}
