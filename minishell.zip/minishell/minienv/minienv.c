/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minienv.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchalak <rchalak@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/10 11:04:04 by rchalak           #+#    #+#             */
/*   Updated: 2024/12/19 15:08:25 by rchalak          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

#include <unistd.h>
#include <stdlib.h>

static void	add_default_env_vars(t_env **list)
{
	char	cwd[1024];

	if (getcwd(cwd, sizeof(cwd)))
		list_append(ft_strjoin("PWD=", cwd), list);
	else
		list_append("PWD=/", list);
	list_append("SHLVL=1", list);
	list_append("_=/usr/bin/env", list);
	if (!minienv_node("PATH", *list))
		list_append("PATH=/bin:/usr/bin", list);
	if (!minienv_node("LS", *list))
		list_append("LS=/usr/bin/ls", list);
}

static void	append_envp_vars(char **envp, t_env **list)
{
	int	i;

	i = 0;
	while (envp[i])
	{
		list_append(envp[i], list);
		i++;
	}
}

t_env	*init_minienv(char **envp)
{
	t_env	*list;
	int		start;
	char	*str;

	list = NULL;
	if (!envp || !envp[0])
	{
		add_default_env_vars(&list);
	}
	else
	{
		append_envp_vars(envp, &list);
	}
	if (!minienv_node("OLDPWD", list))
		list_append("OLDPWD", &list);
	start = ft_atoi(minienv_value("SHLVL", list));
	start++;
	str = ft_itoa(start);
	minienv_update("SHLVL", str, list);
	free(str);
	return (list);
}

/*
Creates a new t_env node with key_pair.
Appends the new node to the end of the list.
*/
void	list_append(char *key_pair, t_env **head)
{
	t_env	*new_node;
	t_env	*current_node;

	new_node = malloc(sizeof(t_env));
	new_node->key_pair = ft_strdup(key_pair);
	new_node->next = NULL;
	if (!*head)
	{
		*head = new_node;
		return ;
	}
	current_node = *head;
	while (current_node->next)
		current_node = current_node->next;
	current_node->next = new_node;
}
